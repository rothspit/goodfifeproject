# 🎓 アイドル学園 - ヘブン更新スケジューラーガイド

## 📋 概要

シティヘブンネットの「ヘブン更新ボタン」を指定された15枠の時間に自動で押すスケジューラーシステム。

---

## 📅 スケジュール（15枠）

```
 1. 07:02
 2. 11:54
 3. 14:55
 4. 17:12
 5. 18:05
 6. 19:15
 7. 20:35
 8. 21:57
 9. 22:26
10. 23:05
11. 23:35
12. 18:36
13. 20:05
14. 21:04
15. 22:44
```

**残り回数**: 毎回自動でカウント（16/16回など）

---

## 🚀 使い方

### **パターン1: スケジューラーを起動（24時間自動実行）**

```bash
cd /home/user/webapp/ad-platform-manager/backend
npx ts-node heaven-update-scheduler.ts
```

**動作**:
- 次の実行時刻まで自動で待機
- 指定時刻に自動でヘブン更新ボタンをクリック
- 残り回数を毎回カウント
- スクリーンショットを自動保存
- 24時間365日、無限ループで実行

**出力例**:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🎓 アイドル学園 - ヘブン更新スケジューラー起動
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 スケジュール（15枠）:
    1. 07:02
    2. 11:54
    3. 14:55
    4. 17:12
    5. 18:05
    6. 19:15
    7. 20:35
    8. 21:57
    9. 22:26
   10. 23:05
   11. 23:35
   12. 18:36
   13. 20:05
   14. 21:04
   15. 22:44

⏰ スケジューラー開始...

⏰ 次回実行時刻: 22:44 (2025/12/25 22:44:00)
⏳ 待機時間: 34分

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🎓 アイドル学園 - ヘブン更新実行
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📅 スケジュール時刻: 22:44
⏰ 実際の実行時刻: 2025/12/25 22:44:02

🚀 ブラウザ起動中...
✅ ブラウザ起動完了

🔐 ログイン中...
✅ ログイン成功

📊 実行前の残り回数: 16/16回
🔄 ヘブン更新ボタンをクリック中...
✅ クリック成功
📊 実行後の残り回数: 15/16回

📸 スクリーンショット保存: screenshots/heaven-update-2244-1766696640123.png

✅ 更新成功
📊 更新成功（残り15/16回）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏰ 次回実行時刻: 23:05 (2025/12/25 23:05:00)
⏳ 待機時間: 21分
```

---

### **パターン2: 1回だけ実行（テスト用）**

```bash
npx ts-node heaven-update-scheduler.ts --once
```

**動作**:
- 即座に1回だけ実行
- 残り回数をカウント
- スクリーンショットを保存
- 終了

---

### **パターン3: PM2でデーモン化（本番運用推奨）**

```bash
# PM2でバックグラウンド起動
pm2 start heaven-update-scheduler.ts --name "heaven-scheduler" --interpreter ts-node

# ステータス確認
pm2 status

# ログ確認
pm2 logs heaven-scheduler

# 停止
pm2 stop heaven-scheduler

# 再起動
pm2 restart heaven-scheduler

# 削除
pm2 delete heaven-scheduler

# 自動起動設定（システム再起動時に自動起動）
pm2 startup
pm2 save
```

---

## 📊 ログとスクリーンショット

### **実行ログ**
場所: `logs/heaven-update-scheduler-YYYY-MM-DD.json`

内容例:
```json
[
  {
    "scheduledTime": "22:44",
    "actualExecutionTime": "2025/12/25 22:44:02",
    "remainingCountBefore": "16/16",
    "remainingCountAfter": "15/16",
    "success": true
  },
  {
    "scheduledTime": "23:05",
    "actualExecutionTime": "2025/12/25 23:05:01",
    "remainingCountBefore": "15/16",
    "remainingCountAfter": "14/16",
    "success": true
  }
]
```

### **スクリーンショット**
場所: `screenshots/heaven-update-HHMM-timestamp.png`

例:
- `screenshots/heaven-update-0702-1766696640123.png`
- `screenshots/heaven-update-1154-1766696640456.png`
- `screenshots/heaven-update-1455-1766696640789.png`

---

## 🛠 トラブルシューティング

### **Q1: スケジューラーが停止してしまう**
```bash
# PM2を使ってデーモン化してください
pm2 start heaven-update-scheduler.ts --name "heaven-scheduler" --interpreter ts-node

# 自動再起動設定
pm2 startup
pm2 save
```

### **Q2: ログインエラーが発生する**
```bash
# 認証情報を確認
# heaven-update-scheduler.ts の以下を確認:
const STORE_ID = '2510055906';
const PASSWORD = 'OgI70vnH';
```

### **Q3: ボタンが見つからないエラー**
- シティヘブンネットの管理画面構造が変更された可能性があります
- スクリーンショットを確認して、ボタンのセレクタを修正してください

### **Q4: 次の実行時刻を手動で確認したい**
```bash
# 現在時刻と次の実行時刻を表示
node -e "
const times = ['07:02','11:54','14:55','17:12','18:05','19:15','20:35','21:57','22:26','23:05','23:35','18:36','20:05','21:04','22:44'];
const now = new Date();
const current = now.getHours() * 60 + now.getMinutes();
const next = times.find(t => {
  const [h,m] = t.split(':').map(Number);
  return h * 60 + m > current;
}) || times[0];
console.log('現在時刻:', now.toLocaleTimeString('ja-JP'));
console.log('次回実行:', next);
"
```

---

## 📈 システム監視

### **リアルタイムログ監視**
```bash
# PM2ログをリアルタイム表示
pm2 logs heaven-scheduler --lines 50

# JSONログをリアルタイム表示
tail -f logs/heaven-update-scheduler-$(date +%Y-%m-%d).json
```

### **実行履歴の確認**
```bash
# 今日のログを確認
cat logs/heaven-update-scheduler-$(date +%Y-%m-%d).json | jq '.'

# 実行成功回数をカウント
cat logs/heaven-update-scheduler-$(date +%Y-%m-%d).json | jq '[.[] | select(.success == true)] | length'

# 残り回数の推移を確認
cat logs/heaven-update-scheduler-$(date +%Y-%m-%d).json | jq '.[] | {time: .actualExecutionTime, remaining: .remainingCountAfter}'
```

---

## 🔧 カスタマイズ

### **スケジュール時間を変更したい場合**

`heaven-update-scheduler.ts` の以下を編集:

```typescript
// 15枠の時間スケジュール（24時間形式）
const SCHEDULE_TIMES = [
  '07:02',
  '11:54',
  // ... 必要に応じて変更
];
```

### **ブラウザを非ヘッドレスモードで起動したい場合**

```typescript
this.browser = await chromium.launch({
  headless: false,  // ← false に変更
  args: ['--no-sandbox', '--disable-setuid-sandbox'],
});
```

---

## 🎯 本番運用チェックリスト

- [ ] PM2でデーモン化
- [ ] `pm2 startup` で自動起動設定
- [ ] `pm2 save` で設定保存
- [ ] ログファイルの定期削除設定（古いログを削除）
- [ ] スクリーンショットの定期削除設定
- [ ] エラー通知の設定（Slack/Emailなど）

---

## 📝 ログローテーション設定例

```bash
# 30日より古いログを削除
find /home/user/webapp/ad-platform-manager/backend/logs -name "heaven-update-scheduler-*.json" -mtime +30 -delete

# cronで自動化（毎日午前3時に実行）
0 3 * * * find /home/user/webapp/ad-platform-manager/backend/logs -name "heaven-update-scheduler-*.json" -mtime +30 -delete
```

---

## 🔐 セキュリティ

- 認証情報は環境変数で管理することを推奨
- スクリーンショットに機密情報が含まれる場合は、アクセス権限を制限

```bash
# スクリーンショットディレクトリのアクセス権限を制限
chmod 700 screenshots/
chmod 600 screenshots/*.png
```

---

## 📞 サポート

問題が発生した場合は、以下のログを確認してください:

1. **PM2ログ**: `pm2 logs heaven-scheduler`
2. **JSONログ**: `logs/heaven-update-scheduler-YYYY-MM-DD.json`
3. **スクリーンショット**: `screenshots/heaven-update-*.png`

---

作成日: 2025-12-25
