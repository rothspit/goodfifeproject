import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

// MySQL接続プール作成
export const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306'),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ad_platform_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: parseInt(process.env.DB_CONNECT_TIMEOUT || '10000'),
});

// 接続テスト
export async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ MySQL データベース接続成功');
    console.log(`   ホスト: ${process.env.DB_HOST}`);
    console.log(`   データベース: ${process.env.DB_NAME}`);
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ データベース接続エラー:', error);
    return false;
  }
}

export default pool;
